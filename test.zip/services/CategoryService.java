package edu.poly.spring.services;

public interface CategoryService {

}
