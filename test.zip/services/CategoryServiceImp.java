package edu.poly.spring.services;

import java.util.Optional;

import org.springframework.stereotype.Service;

import edu.poly.spring.models.Category;
import edu.poly.spring.repositories.CategoryRepository;

@Service
public class CategoryServiceImp implements CategoryService {
	private CategoryRepository categoryRepository;

	public <S extends Category> S save(S entity) {
		return categoryRepository.save(entity);
	}

	public <S extends Category> Iterable<S> saveAll(Iterable<S> entities) {
		return categoryRepository.saveAll(entities);
	}

	public Optional<Category> findById(String id) {
		return categoryRepository.findById(id);
	}

	public boolean existsById(String id) {
		return categoryRepository.existsById(id);
	}

	public Iterable<Category> findAll() {
		return categoryRepository.findAll();
	}

	public Iterable<Category> findAllById(Iterable<String> ids) {
		return categoryRepository.findAllById(ids);
	}

	public long count() {
		return categoryRepository.count();
	}

	public void deleteById(String id) {
		categoryRepository.deleteById(id);
	}

	public void delete(Category entity) {
		categoryRepository.delete(entity);
	}

	public void deleteAll(Iterable<? extends Category> entities) {
		categoryRepository.deleteAll(entities);
	}

	public void deleteAll() {
		categoryRepository.deleteAll();
	}
	
}
