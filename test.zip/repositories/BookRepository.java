package edu.poly.spring.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.poly.spring.models.Book;
@Repository
public interface BookRepository extends CrudRepository<Book, String> {

}
