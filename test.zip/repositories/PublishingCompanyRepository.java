package edu.poly.spring.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.poly.spring.models.PublishingCompany;

@Repository
public interface PublishingCompanyRepository extends CrudRepository<PublishingCompany, String> {

}
